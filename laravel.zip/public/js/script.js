document.querySelector("#hamburger").addEventListener("click",()=>{
    const menu = document.querySelector("#mobile-menu")
    menu.classList.toggle("hidden")
})