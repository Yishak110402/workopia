<nav>
    <a href="/">Home</a>
    <a href="/jobs">Jobs</a>
    <a href="/jobs/create">Create Job</a>
</nav><?php /**PATH C:\Users\Yishak\Herd\workopea\resources\views/partials/navbar.blade.php ENDPATH**/ ?>