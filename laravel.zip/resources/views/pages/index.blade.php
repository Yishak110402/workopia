<x-layout>
    
    <h1>Welcome to Workopia</h1>
    <x-bottom-banner/>

</x-layout>