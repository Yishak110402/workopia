<x-layout>
    <x-slot name="title">Create Job</x-slot>
    <h1>{{ $title }}</h1> 
    <form action="/jobs" method="post">
        @csrf
        <br>
        <input type="text" name="title" placeholder="Title" id="">
        <br>
        <br>
        <input type="text" name="description" placeholder="Descrption" id="">
        <br>
        <input type="submit" value="Add Job">
    </form>  
</x-layout>

