<x-layout>

    <h1>{{ $title }}</h1>
    <ul>
        @forelse($jobs as $job)
            <li>{{ $loop->iteration }} - {{ $job }}</li>
        @empty
            <li>No Jobs Available</li>
        @endforelse
    </ul>
</x-layout>
