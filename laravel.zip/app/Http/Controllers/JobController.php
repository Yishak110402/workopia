<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class JobController extends Controller
{
   public function index(){
      $title = "All Job Listings in our site";
      $jobs = [
          "System Admin",
          "mL Engineer",
          "Web Developer"
      ];
      return view("jobs.index",[
          "title" => $title,
          "jobs" => $jobs
      ]);
   }
   public function create(){
      $title = "Create Job Listing";
      return view("jobs.create", [
         "title"=>$title
      ]);
      
   }
   public function show(string $id){
      return "Showing Job $id" ;
   }
   public function store(Request $request){
      $description = $request->input("description");
      $title = $request->input("title");
      return "Title: $title, Description: $description" ;
   }
}
